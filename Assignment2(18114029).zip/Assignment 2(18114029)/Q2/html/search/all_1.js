var searchData=
[
  ['initialize_5fn',['initialize_n',['../MAT_8c.html#abf9f6d89541302353593bda79b8184d8',1,'MAT.c']]]
];
