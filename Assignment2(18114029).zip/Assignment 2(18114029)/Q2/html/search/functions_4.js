var searchData=
[
  ['read_5finputfile',['read_inputfile',['../MAT_8c.html#ab70cc76fff672f86c37003cb307eb4d3',1,'MAT.c']]]
];
