var searchData=
[
  ['read_5ffile',['read_file',['../compareFiles_8c.html#ad1d0618247f01bfc24c92912798c6bd9',1,'read_file(char filename[], char *output):&#160;compareFiles.c'],['../inverseTranspose_8c.html#a3e2bb97890b4277d4c59c7e5986ff4a3',1,'read_file(char filename[], char *output, struct key Key):&#160;inverseTranspose.c'],['../transpose_8c.html#a3e2bb97890b4277d4c59c7e5986ff4a3',1,'read_file(char filename[], char *output, struct key Key):&#160;transpose.c']]]
];
