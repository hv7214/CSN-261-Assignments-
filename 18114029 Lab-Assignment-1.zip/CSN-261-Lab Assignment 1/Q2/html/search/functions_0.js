var searchData=
[
  ['init_5fdeque',['init_deque',['../Q2_8c.html#aac4a9bf6c900c2d342874bdc31a6ea5f',1,'Q2.c']]]
];
