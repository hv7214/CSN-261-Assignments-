var searchData=
[
  ['resize_5fdbl',['resize_dbl',['../Q2_8c.html#a02d79fa3e22949f8e78c436f7e78e8ea',1,'Q2.c']]],
  ['resize_5fhalf',['resize_half',['../Q2_8c.html#ac2563e7a3cbdfe741f24899da0f0116d',1,'Q2.c']]]
];
