var indexSectionsWithContent =
{
  0: "dghilmnpqsu",
  1: "n",
  2: "q",
  3: "dilmpsu",
  4: "ghlu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

