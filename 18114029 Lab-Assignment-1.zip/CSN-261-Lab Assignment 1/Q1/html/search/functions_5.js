var searchData=
[
  ['search',['search',['../Q1_8c.html#a38cef1d681edcb0015ee311060ed9563',1,'Q1.c']]],
  ['sort_5fa_5fz',['sort_a_z',['../Q1_8c.html#a67e5a625328611de966f3d2c50a18844',1,'Q1.c']]]
];
