var searchData=
[
  ['unusedrollno_5finsert',['UnusedRollNo_insert',['../Q1_8c.html#a023b058131a82580edd2ca1ac9fa0f18',1,'Q1.c']]]
];
