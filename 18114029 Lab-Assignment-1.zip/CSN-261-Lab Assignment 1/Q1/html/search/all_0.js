var searchData=
[
  ['delete',['Delete',['../Q1_8c.html#a47b53d10a4c79cffc14b7a32c37e4775',1,'Q1.c']]]
];
