var searchData=
[
  ['unusedrollno',['unusedRollNo',['../Q1_8c.html#a8439f5c29c9cd4add2f65076beb7dbd0',1,'Q1.c']]],
  ['unusedrollno_5finsert',['UnusedRollNo_insert',['../Q1_8c.html#a023b058131a82580edd2ca1ac9fa0f18',1,'Q1.c']]]
];
