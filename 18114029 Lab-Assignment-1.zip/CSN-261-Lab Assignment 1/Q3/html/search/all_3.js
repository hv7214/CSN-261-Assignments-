var searchData=
[
  ['read_5fblue',['Read_blue',['../Q3_8c.html#aac13f719ec7108f844fea0319006bde1',1,'Q3.c']]],
  ['read_5fgreen',['Read_green',['../Q3_8c.html#a167cb5d6357903f1fc9b94b629ab4043',1,'Q3.c']]],
  ['read_5fred',['Read_red',['../Q3_8c.html#a09ecef8c18f8b5bab2d01d0451e907d9',1,'Q3.c']]],
  ['remove_5fblue',['Remove_Blue',['../Q3_8c.html#aae7185588ba0e62c9ba534b49caf7546',1,'Q3.c']]],
  ['remove_5fgreen',['Remove_Green',['../Q3_8c.html#aadd9541452fb9fa7226ed04ae2034d9e',1,'Q3.c']]],
  ['remove_5fred',['Remove_Red',['../Q3_8c.html#a78cbe457ac1ce0a789fd5f4cf628fd3c',1,'Q3.c']]]
];
