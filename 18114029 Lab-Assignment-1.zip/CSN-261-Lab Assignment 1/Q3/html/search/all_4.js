var searchData=
[
  ['write_5fblue_5fdat',['Write_blue_dat',['../Q3_8c.html#a1e063e4a3e59fc2742b9656356865fb0',1,'Q3.c']]],
  ['write_5fgreen_5fdat',['Write_green_dat',['../Q3_8c.html#a57037066c67817fd075bab439b2554bb',1,'Q3.c']]],
  ['write_5fred_5fdat',['Write_red_dat',['../Q3_8c.html#a9142417505d65bc51a1599c0938f1500',1,'Q3.c']]]
];
