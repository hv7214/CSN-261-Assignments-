var searchData=
[
  ['init',['init',['../Q2_8cpp.html#a537f43ea13b4483880870266df79dc9b',1,'Q2.cpp']]],
  ['insert',['insert',['../classLinkedList.html#a78c01c1f298ae68de1f090649faa36a7',1,'LinkedList']]]
];
