var searchData=
[
  ['checkforattack',['checkforattack',['../Q2_8cpp.html#ae43ce834bfded92bcc73455a6bea91a8',1,'Q2.cpp']]]
];
