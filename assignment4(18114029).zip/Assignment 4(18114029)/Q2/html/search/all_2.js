var searchData=
[
  ['nqueen',['nQueen',['../Q2_8cpp.html#ae7fa013c55d128293f33392b3ff3cdbf',1,'Q2.cpp']]]
];
